//___FILEHEADER___

import UIKit

/// ___VARIABLE_productName:identifier___ Module Router (aka: Wireframe)
class ___VARIABLE_productName:identifier___Router: ___VARIABLE_productName:identifier___RouterProtocol {
    
    var navigationController: UINavigationController
    
    
    init(navigationController: UINavigationController) {
        self.navigationController = navigationController
    }
    
    
    // Aqui implementaremos as funções de showModule/showView, exemplo:
    // func presentViewController1(object: SomeObject, vcToShow: Vc) {
    //    // No caso dessa vc precisaremos passar dados para ela,
    //    // por isso o parâmetro object.
    //    vcToShow.name = object.name
    //    vcToShow.year = object.year
    //    navigationController.pushViewController(vcToShow, animated: true)
}
