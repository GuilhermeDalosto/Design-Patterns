//___FILEHEADER___

import UIKit

/// ___VARIABLE_productName:identifier___ Module Router Protocol (aka: Wireframe)
protocol ___VARIABLE_productName:identifier___RouterProtocol {
    
    var navigationController: UINavigationController { get set }
}
