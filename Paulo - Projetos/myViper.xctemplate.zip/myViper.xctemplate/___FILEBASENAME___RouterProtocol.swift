//___FILEHEADER___

import UIKit

/// ___VARIABLE_productName:identifier___ Module Router Protocol (aka: Wireframe)
protocol ___VARIABLE_productName:identifier___RouterProtocol {
    
    /// A ViewController que está requisitando o novo Module, ex: viewController.show(newVc)
    //var parentViewController: HumanoidView! { get set }
    
    /*
     Exemplo de funcionamento:
     func showNewModule() {
         let view = parentViewController.storyboard?.instantiateViewController(withIdentifier: newModuleName) as! newModuleNameView
         parentViewController.show(view, sender: nil)
     }
     */
}
