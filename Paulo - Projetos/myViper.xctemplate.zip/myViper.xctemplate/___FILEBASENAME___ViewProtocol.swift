//___FILEHEADER___

import UIKit


/// ___VARIABLE_productName:identifier___ Module View Protocol
/// Implementamos funções para a visualização dos dados.
protocol ___VARIABLE_productName:identifier___ViewProtocol: class {
    
    /// Atualizamos a UI com o valor retornado.
    /// - Parameter object: Objeto - EntityView - que será mostrado na UI. Deve já vir preparado do Presenter para a visualização
    func set(object: ___VARIABLE_productName:identifier___Entity.___VARIABLE_productName:identifier___View)
}
