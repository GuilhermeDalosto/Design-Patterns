//___FILEHEADER___

import UIKit

/// ___VARIABLE_productName:identifier___ Module Interactor Protocol
protocol ___VARIABLE_productName:identifier___InteractorProtocol {
    /// Chamado pelo Presenter.
    /// É aqui que damos fetch em um banco ou framework
    /// para pegar os dados, também é possível que seja feita
    /// alguma transformação dos dados resgatados.
    /// - Parameter presenter: Presenter que está pedindo os dados.
    func fetch(objectFor presenter: ___VARIABLE_productName:identifier___PresenterProtocol)
    
    /// Suppose we have a database to store the incoming object from presenter.
    /// - Parameter object: Objeto - EntityData - que será armazenado no banco.
    func store(objectToStore object: ___VARIABLE_productName:identifier___Entity.___VARIABLE_productName:identifier___Data)
}
