//___FILEHEADER___

import UIKit

/// ___VARIABLE_productName:identifier___ Module Presenter Protocol
protocol ___VARIABLE_productName:identifier___PresenterProtocol {
    
    /// Chamado pela View para resgatar dados do banco que serão postos na UI.
    /// - Parameter view: View que está requisitando os dados.
    func fetch(objectFor view: ___VARIABLE_productName:identifier___ViewProtocol)
    
    /// Chamado pelo Interactor quando o fetch foi concluído com sucesso. Daqui de dentro chamamos a View para mostrar os dados recebidos
    /// - Parameters:
    ///   - object: Objecto resgatado com sucesso pelo interactor, que será enviado para a View pelo Presenter.
    func interactor(didFetch object: ___VARIABLE_productName:identifier___Entity.___VARIABLE_productName:identifier___Data)
    
    /// Chamado pelo Interactor quando ocorrer erro no fetch. Daqui de dentro fazemos o tratamento do erro, e como ele irá para a UI
    /// - Parameters:
    ///   - error: Descrição do erro encontrado pelo Interactor ao resgatar o dado no banco.
    func interactor(didFailWith error: Error)
    
    /// Chamamos o Presenter quando tivemos uma ação que requer que guardamos um dado.
    /// - Parameters:
    ///   - object: Objeto que será guardado no banco.
    //func store(___VARIABLE_productName:identifier___ object: ___VARIABLE_productName:identifier___Entity.___VARIABLE_productName:identifier___View)
    
    /// Função chamada pela View quando for mudar de Module (transição)
    /// - Parameters:
    ///   - moduleName: Nome do Module o qual estamos indo.
    ///   - parentView: ViewController do Module anterior.
    //func showModule(_ moduleName: String, parentView: ___VARIABLE_productName:identifier___View)
}
