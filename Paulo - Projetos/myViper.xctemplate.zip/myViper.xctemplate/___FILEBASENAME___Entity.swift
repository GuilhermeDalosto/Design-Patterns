//___FILEHEADER___

import UIKit


/// ___VARIABLE_productName:identifier___ Module Entity
enum ___FILEBASENAME___ {
    
    /// Struct for fetching data from Network layer
    struct ___VARIABLE_productName:identifier___Data {
        
    }
    
    
    /// Struct for showing data on View layer
    struct ___VARIABLE_productName:identifier___View {
        
    }
}
