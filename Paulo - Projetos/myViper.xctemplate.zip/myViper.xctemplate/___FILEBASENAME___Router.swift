//___FILEHEADER___

import UIKit

/// ___VARIABLE_productName:identifier___ Module Router (aka: Wireframe)
class ___VARIABLE_productName:identifier___Router: ___VARIABLE_productName:identifier___RouterProtocol {
    
    //weak var parentViewController: ___VARIABLE_productName:identifier___View!
        
}
