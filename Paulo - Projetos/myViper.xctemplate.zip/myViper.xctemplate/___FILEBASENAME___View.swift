//___FILEHEADER___

import UIKit

/// ___VARIABLE_productName:identifier___ Module View
class ___VARIABLE_productName:identifier___View: UIViewController {
    
    private var presenter: ___VARIABLE_productName:identifier___PresenterProtocol!
    private var object: ___VARIABLE_productName:identifier___Entity?
    //MARK: - Outles:
    
    
    override func viewDidLoad() {
        super.viewDidLoad()
        presenter = ___VARIABLE_productName:identifier___Presenter(view: self)
        
        // Informs the Presenter that the View is ready to receive data.
        presenter.fetch(objectFor: self)
    }
    
    
    //MARK: - Actions:
    
}

// MARK: - implementing ___VARIABLE_productName:identifier___ViewProtocol
extension ___VARIABLE_productName:identifier___View: ___VARIABLE_productName:identifier___ViewProtocol {
    
    func set(object: ___VARIABLE_productName:identifier___Entity.___VARIABLE_productName:identifier___View) {
        
    }
}
