//___FILEHEADER___

import UIKit

// MARK: AINDA PRECISO VER A IMPLEMENTAÇÃO DESSA LAYER
// MARK: PARECE SER ÚTIL
/*
/// ___VARIABLE_productName:identifier___ViewUI Delegate
protocol ___VARIABLE_productName:identifier___ViewUIDelegate {
    // Send Events to Module View, that will send events to the Presenter; which will send events to the Receiver e.g. Protocol OR Component.
}

// MARK: ___VARIABLE_productName:identifier___ViewUI Data Source -
/// ___VARIABLE_productName:identifier___ViewUI Data Source
protocol ___VARIABLE_productName:identifier___ViewUIDataSource {
    // This will be implemented in the Module View.
    /// Set Object for the UI Component
    func objectFor(ui: ___VARIABLE_productName:identifier___ViewUI) -> ___VARIABLE_productName:identifier___Entity
}

class ___VARIABLE_productName:identifier___ViewUI: UIView {
    
    var delegate: ___VARIABLE_productName:identifier___ViewUIDelegate?
    var dataSource: ___VARIABLE_productName:identifier___ViewUIDataSource?
    
    var object : ___VARIABLE_productName:identifier___Entity?
    
    override init(frame: CGRect) {
        super.init(frame: frame)
        setupUIElements()
    }
    
    required init?(coder aDecoder: NSCoder) {
        super.init(coder: aDecoder)
    }
    
    override func didMoveToWindow() {
        super.didMoveToWindow()
        setupConstraints()
    }
    
    fileprivate func setupUIElements() {
        // arrange subviews
    }
    
    fileprivate func setupConstraints() {
        // add constraints to subviews
    }
    
    /// Reloading the data and update the ui according to the new data
    func reloadData() {
        self.object = dataSource?.objectFor(ui: self)
        // Should update UI
    }
}
 */
