//___FILEHEADER___

import UIKit


/// ___VARIABLE_productName:identifier___ Module Interactor
class ___VARIABLE_productName:identifier___Interactor: ___VARIABLE_productName:identifier___InteractorProtocol {

    func fetch(objectFor presenter: ___VARIABLE_productName:identifier___PresenterProtocol) {
        
    }
    
    
    func store(objectToStore object: ___VARIABLE_productName:identifier___Entity.___VARIABLE_productName:identifier___Data) {
        
    }
}
