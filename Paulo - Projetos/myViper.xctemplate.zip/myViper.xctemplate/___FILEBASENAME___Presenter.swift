//___FILEHEADER___

import UIKit

/// ___VARIABLE_productName:identifier___ Module Presenter
class ___VARIABLE_productName:identifier___Presenter {
    
    weak private var view: ___VARIABLE_productName:identifier___ViewProtocol?
    private var interactor: ___VARIABLE_productName:identifier___InteractorProtocol
    private var wireframe: ___VARIABLE_productName:identifier___RouterProtocol
    
    init(view: ___VARIABLE_productName:identifier___ViewProtocol) {
        self.view = view
        self.interactor = ___VARIABLE_productName:identifier___Interactor()
        self.wireframe = ___VARIABLE_productName:identifier___Router()
    }
}

// MARK: - extending ___VARIABLE_productName:identifier___Presenter to implement it's protocol
extension ___VARIABLE_productName:identifier___Presenter: ___VARIABLE_productName:identifier___PresenterProtocol {
    
    func fetch(objectFor view: ___VARIABLE_productName:identifier___ViewProtocol) {
        
    }
    
    
    func interactor(didFetch object: ___VARIABLE_productName:identifier___Entity.___VARIABLE_productName:identifier___Data) {
        
    }
    
    
    func interactor(didFailWith error: Error) {
        
    }
}
